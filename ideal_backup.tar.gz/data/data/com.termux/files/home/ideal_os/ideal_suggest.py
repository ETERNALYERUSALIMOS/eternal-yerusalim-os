print("Пост BESTPARFUM: +5k сегодня!")
