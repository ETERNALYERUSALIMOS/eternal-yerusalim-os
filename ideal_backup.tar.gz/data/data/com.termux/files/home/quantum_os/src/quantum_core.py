print("🕊 QUANTUM OS active! Qiskit qubits...")
