from qiskit import QuantumCircuit
qc = QuantumCircuit(1,1)
qc.h(0)
qc.measure(0,0)
print("🕊 Qubit entangled! " + str(qc.draw()))
