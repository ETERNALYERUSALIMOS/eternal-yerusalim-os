print("BESTPARFUM: День 2026-02-06 | Стрик +1 | t.me/BestParfum | #парфюмстойкий #sillage")
