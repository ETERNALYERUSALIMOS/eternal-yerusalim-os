from conan.tools.premake.premake import Premake
from conan.tools.premake.premakedeps import PremakeDeps